//
//  TableViewCellServicio.swift
//  EX3_T6CN_01_IDROGO_GIANCARLO
//
//  Created by DAMII on 7/19/20.
//  Copyright © 2020 Cibertec. All rights reserved.
//

import UIKit

class TableViewCellServicio: UITableViewCell {
    
    @IBOutlet weak var lblOrden: UILabel!
    
    @IBOutlet weak var lblFecha: UILabel!
    
    
    @IBOutlet weak var lblCliente: UILabel!
    
   // @IBOutlet weak var btnVerRegistro: UIButton!
      var objServicioInterno: objServicio!
   //   var ObjSelf: ViewControllerListaProveedor!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    public func MostrarRegistro(pServicio: objServicio) //, pSelf: ViewControlle)
       {
        self.objServicioInterno = pServicio
        self.lblOrden.text = pServicio.NumeroOrdenServicio
        self.lblCliente.text = pServicio.NombreCliente
        self.lblFecha.text = pServicio.FechaProgramada
         //  self.ObjSelf = pSelf
           
       }

}

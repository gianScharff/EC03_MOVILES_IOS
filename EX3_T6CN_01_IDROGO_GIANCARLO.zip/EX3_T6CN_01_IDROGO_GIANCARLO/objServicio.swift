//
//  objServicio.swift
//  EX3_T6CN_01_IDROGO_GIANCARLO
//
//  Created by DAMII on 7/19/20.
//  Copyright © 2020 Cibertec. All rights reserved.
//

import UIKit

class objServicio: NSObject {
    
   
    var CodigoServicio: integer_t
    var NombreCliente: String
    var NumeroOrdenServicio: String
    var FechaProgramada: String
    var Linea: String
    var Estado: String
       
       override init() {
            self.CodigoServicio = 0
            self.NombreCliente = ""
            self.NumeroOrdenServicio = ""
            self.FechaProgramada = ""
            self.Linea = ""
            self.Estado = ""
        
       }
       
       init(pCodigoServicio: integer_t, pNombreCliente: String!, pNumeroOrdenServicio: String!, pFechaProgramada: String!, pLinea: String!, pEstado: String!) {
              self.CodigoServicio = pCodigoServicio
              self.NombreCliente = pNombreCliente
              self.NumeroOrdenServicio = pNumeroOrdenServicio
              self.FechaProgramada = pFechaProgramada
              self.Linea = pLinea
              self.Estado = pEstado
          }
}

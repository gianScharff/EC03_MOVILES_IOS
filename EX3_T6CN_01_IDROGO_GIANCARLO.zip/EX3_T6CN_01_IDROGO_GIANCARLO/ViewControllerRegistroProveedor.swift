//
//  ViewControllerRegistroProveedor.swift
//  EX3_T6CN_01_IDROGO_GIANCARLO
//
//  Created by DAMII on 7/19/20.
//  Copyright © 2020 Cibertec. All rights reserved.
//

import UIKit

class ViewControllerRegistroProveedor: UIViewController {

    
    @IBOutlet weak var tfCodigoServicio: UITextField!
    @IBOutlet weak var tfNombreCliente: UITextField!
    @IBOutlet weak var tfNumeroOrdenServicio: UITextField!
    @IBOutlet weak var tfFechaProgramada: UITextField!
    @IBOutlet weak var tfLinea: UITextField!
    @IBOutlet weak var tfEstado: UITextField!
    @IBOutlet weak var tfObservaciones: UITextField!
    
    @IBOutlet weak var lblRespuesta: UILabel!
    
    var objServicioInternoRegistro: objServicio!
   
    
    override func viewDidLoad() {
        super.viewDidLoad()
    // Do any additional setup after loading the view.
    }

    @IBAction func btnGrabar_onClick(_ sender: Any) {
        
        var pTipoTransaccion:String="N"
        let urlListado1 = "http://cibertec202021-001-site1.etempurl.com/Servicio/RegistraModifica?Accion=" + pTipoTransaccion +
                         "&CodigoServicio=" + "1" + //String(objProveedorInternoRegistro.CodigoProveedor) +
                         "&NombreCliente=\(self.tfNombreCliente.text!)" +
                         "&NumeroOrdenServicio=" + self.tfNumeroOrdenServicio.text! +
                         "&FechaProgramada=" + self.tfFechaProgramada.text! +
                         "&Linea=" + self.tfLinea.text! +
                         "&Estado=" + self.tfEstado.text! +
                         "&Observaciones=" + self.tfObservaciones.text!
       
        var urlListado  = urlListado1.addingPercentEncoding(withAllowedCharacters: CharacterSet.urlQueryAllowed)!
        let urlConsulta = URL(string : urlListado)
        let peticion = URLRequest(url : urlConsulta!)
        let tarea = URLSession.shared.dataTask(with: peticion)
                      {Datos, Respuesta, Error in
                          print("por iniciar")
                          if (Error == nil)
                          {
                              print("Por procesar Datos")
                              print(Datos ?? "Vacio")
                              let datosCadena = NSString(data: Datos!, encoding: String.Encoding.utf8.rawValue)
                              print (datosCadena!)
                              print("Fin procesar Datos")
                              
                              DispatchQueue.main.async {
                                  //Inicio Completar la lectura de objetos JSON
                                  let JSON = try? JSONSerialization.jsonObject(with: Datos!, options: [])
                                  
                                   if let objServiciotmp = JSON as? [String: Any]
                                                     {
                                          let CodigoServicio = objServiciotmp["CodigoServicio"] as! integer_t
                                          //              self.objServicioInternoRegistro.CodigoServicio = CodigoServicio
                                          self.tfCodigoServicio.text = String (CodigoServicio)
                                            
                                  }
                                  //Fin Completar la lectura de objetos JSON
                                 self.lblRespuesta.text = "Servicio registrado correctamente !!!!"
                              }
                              //let resultado = datosCadena! as String
                          }
                          else
                          {
                              print("Error")
                              print(Error ?? "Error vacio")
                              //let strCadena = Error as! String
                              //self.tvMensaje.text = strCadena
                          }
                      }
                      tarea.resume()    }
 
}

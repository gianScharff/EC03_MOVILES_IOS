//
//  ViewController.swift
//  EX3_T6CN_01_IDROGO_GIANCARLO
//
//  Created by DAMII on 7/19/20.
//  Copyright © 2020 Cibertec. All rights reserved.
//

import UIKit

class ViewController: UIViewController, UITableViewDataSource, UITableViewDelegate  {
    @IBOutlet weak var tfCodigoOrden: UITextField!
    @IBOutlet weak var tfNombreCliente: UITextField!
    @IBOutlet weak var tvListaServicio: UITableView!
    @IBOutlet weak var lblMensaje: UILabel!
    var oListaServicios = [objServicio]()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.tvListaServicio.dataSource = self
        self.tvListaServicio.delegate = self
        self.tvListaServicio.rowHeight = 150
        cargar()
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
         return oListaServicios.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let oCelda = tableView.dequeueReusableCell(withIdentifier: "CeldaServicio", for: indexPath) as! TableViewCellServicio
        let oRegServicio=oListaServicios[indexPath.row]
        oCelda.MostrarRegistro(pServicio: oRegServicio) //, pSelf: self)
        return oCelda
    }

  
    
    @IBAction func btnNuevo_onClick(_ sender: Any) {
         let storyBoard: UIStoryboard = UIStoryboard(name: "Main", bundle: nil)
         let oPantalla2 = storyBoard.instantiateViewController(withIdentifier: "viewRegistroServicio") as! ViewControllerRegistroProveedor
         self.present(oPantalla2, animated: true, completion: nil)
    }
    
    

    
    
    @IBAction func btnBuscar_onClick(_ sender: UIButton) {
        oListaServicios = [objServicio]()
        var urlListado1 = "http://cibertec202021-001-site1.etempurl.com/Servicio/Listar?"
        
        if (tfCodigoOrden.text == ""){
            urlListado1 = urlListado1 + "NombreCliente=" + self.tfNombreCliente.text!
        }
        else
        {
            urlListado1 = urlListado1 + "NumeroOrdenServicio=" + self.tfCodigoOrden.text!
        }
        
        var urlListado  = urlListado1.addingPercentEncoding(withAllowedCharacters: CharacterSet.urlQueryAllowed)!
        
        let urlConsulta = URL(string: urlListado)
        let peticion = URLRequest(url: urlConsulta!)
        let tarea = URLSession.shared.dataTask(with: peticion)
                            {Datos, Respuesta, Error in
                                print("por iniciar")
                                if (Error == nil)
                                {
                                    print("Por procesar Datos")
                                    print(Datos ?? "Vacio")
                                    let datosCadena = NSString(data: Datos!, encoding: String.Encoding.utf8.rawValue)
                                    print (datosCadena!)
                                    print("Fin procesar Datos")
                                    
                                    DispatchQueue.main.async {
                                        let JSON = try? JSONSerialization.jsonObject(with: Datos!, options: [])
                                            if let dictionary = JSON as? [[String: Any]] //,let WSListaUsuarios = dictionary["0"] as? [[String: Any]]
                                       
                                            {
                                            dictionary.forEach { Registro in
                                                let CodigoServicio = Registro["CodigoServicio"] as! integer_t
                                                let NombreCliente = Registro["NombreCliente"] as? String
                                                let NumeroOrdenServicio = Registro["NumeroOrdenServicio"] as? String
                                                let FechaProgramada = Registro["FechaProgramada"] as? String
                                                let Linea = Registro["Linea"] as? String
                                                let Estado = Registro["Estado"] as? String
                                                let Servicio1 = objServicio(pCodigoServicio: CodigoServicio, pNombreCliente: NombreCliente, pNumeroOrdenServicio: NumeroOrdenServicio, pFechaProgramada: FechaProgramada, pLinea: Linea, pEstado: Estado)
                                                self.oListaServicios.append(Servicio1)
                                            }
                                            self.lblMensaje.text = "\(self.oListaServicios.count) usuarios encontrados"
                                            self.tvListaServicio.reloadData()
                                        }
                                        //Fin Completar la lectura de objetos JSON
                                    }
                                    //let resultado = datosCadena! as String
                                }
                                else
                                {
                                    print("Error")
                                    print(Error ?? "Error vacio")
                                }
                            }
                            tarea.resume()
        
    }
    
    
    func cargar(){
        
                          oListaServicios = [objServicio]()
                          let urlListado = "http://cibertec202021-001-site1.etempurl.com/Servicio/Listar/"
                          print (urlListado)
                          let urlConsulta = URL(string: urlListado)
                          let peticion = URLRequest(url: urlConsulta!)
                          
                          let tarea = URLSession.shared.dataTask(with: peticion)
                          {Datos, Respuesta, Error in
                              print("por iniciar")
                              if (Error == nil)
                              {
                                  print("Por procesar Datos")
                                  print(Datos ?? "Vacio")
                                  let datosCadena = NSString(data: Datos!, encoding: String.Encoding.utf8.rawValue)
                                  print (datosCadena!)
                                  print("Fin procesar Datos")
                                  
                                  DispatchQueue.main.async {
                                      //Inicio Completar la lectura de objetos JSON
                                      let JSON = try? JSONSerialization.jsonObject(with: Datos!, options: [])
                                      
                            
                                          if let dictionary = JSON as? [[String: Any]] //,let WSListaUsuarios = dictionary["0"] as? [[String: Any]]
                                     
                                          
                                          {
                                          dictionary.forEach { Registro in
                                              let CodigoServicio = Registro["CodigoServicio"] as! integer_t
                                              let NombreCliente = Registro["NombreCliente"] as? String
                                              let NumeroOrdenServicio = Registro["NumeroOrdenServicio"] as? String
                                              let FechaProgramada = Registro["FechaProgramada"] as? String
                                              let Linea = Registro["Linea"] as? String
                                              let Estado = Registro["Estado"] as? String
                                              let Servicio1 = objServicio(pCodigoServicio: CodigoServicio, pNombreCliente: NombreCliente, pNumeroOrdenServicio: NumeroOrdenServicio, pFechaProgramada: FechaProgramada, pLinea: Linea, pEstado: Estado)
                                            
                                             self.oListaServicios.append(Servicio1)
                                          }
                                          self.lblMensaje.text = "\(self.oListaServicios.count) usuarios encontrados"
                                          self.tvListaServicio.reloadData()
                                      }
                                      //Fin Completar la lectura de objetos JSON
                                  }
                                  //let resultado = datosCadena! as String
                              }
                              else
                              {
                                  print("Error")
                                  print(Error ?? "Error vacio")
                                  //let strCadena = Error as! String
                                  //self.tvMensaje.text = strCadena
                              }
                          }
                          tarea.resume()
        
    }
}


